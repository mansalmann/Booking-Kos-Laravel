<?php $__env->startSection('content'); ?>
<div id="Background"
class="absolute top-0 w-full h-[430px] rounded-b-[75px] bg-[linear-gradient(180deg,#F2F9E6_0%,#D2EDE4_100%)]">
</div>
<div class="relative flex flex-col gap-[30px] my-[60px] px-5">
<h1 class="font-bold text-[30px] leading-[45px] text-center">Periksa<br>Detail Pemesanan</h1>
<form action="<?php echo e(route('show-booking-details')); ?>" method="POST"
    class="flex flex-col rounded-[30px] border border-[#F1F2F6] p-5 gap-6 bg-white">
    <?php echo csrf_field(); ?>
    <?php if(session('error')): ?>
        <p class="text-center text-red-500"><?php echo e(session('error')); ?></p>
    <?php endif; ?>
    <div class="flex flex-col gap-[6px]">
        <h1 class="font-semibold text-lg">Informasi Pembayaran</h1>
        <p class="text-sm text-ngekos-grey">Isi formulir berikut dengan data sebenarnya</p>
    </div>
    <div id="InputContainer" class="flex flex-col gap-[18px]">
        <div class="flex flex-col w-full gap-2">
            <p class="font-semibold">ID Pemesanan</p>
            <label
                class="flex items-center w-full rounded-full p-[14px_20px] gap-3 bg-white ring-1 ring-[#F1F2F6] focus-within:ring-[#91BF77] transition-all duration-300">
                <img src="<?php echo e(asset('assets/images/icons/note-favorite-grey.svg')); ?>" class="w-5 h-5 flex shrink-0"
                    alt="icon">
                <input type="text" name="code" id="code"
                    class="appearance-none outline-none w-full font-semibold placeholder:text-ngekos-grey placeholder:font-normal"
                    placeholder="Tulis ID Pemesanan Anda" value="<?php echo e(old('code')); ?>">
            </label>
            <?php $__errorArgs = ['code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class="text-sm text-red-500"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="flex flex-col w-full gap-2">
            <p class="font-semibold">Email</p>
            <label
                class="flex items-center w-full rounded-full p-[14px_20px] gap-3 bg-white ring-1 ring-[#F1F2F6] focus-within:ring-[#91BF77] transition-all duration-300">
                <img src="<?php echo e(asset('assets/images/icons/sms.svg')); ?>" class="w-5 h-5 flex shrink-0" alt="icon">
                <input type="email" name="email" id="email"
                    class="appearance-none outline-none w-full font-semibold placeholder:text-ngekos-grey placeholder:font-normal"
                    placeholder="Tulis email Anda" value="<?php echo e(old('email')); ?>">
            </label>
            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class="text-sm text-red-500"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="flex flex-col w-full gap-2">
            <p class="font-semibold">Nomor Telepon</p>
            <label
                class="flex items-center w-full rounded-full p-[14px_20px] gap-3 bg-white ring-1 ring-[#F1F2F6] focus-within:ring-[#91BF77] transition-all duration-300 border-color-500">
                <img src="<?php echo e(asset('assets/images/icons/call.svg')); ?>" class="w-5 h-5 flex shrink-0" alt="icon">
                <input type="tel" name="phone_number" id="phone_number"
                    class="appearance-none outline-none w-full font-semibold placeholder:text-ngekos-grey placeholder:font-normal"
                    placeholder="Tulis nomor telepon Anda" value="<?php echo e(old('phone_number')); ?>">
            </label>
            <?php $__errorArgs = ['phone_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class="text-sm text-red-500"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <button type="submit"
            class="flex w-full justify-center rounded-full p-[14px_20px] bg-ngekos-orange font-bold text-white">Lihat Pemesanan Anda</button>
    </div>
</form>
</div>
<?php echo $__env->make('includes.navigation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Programming\Laravel\WebBookingKos\resources\views/pages/booking/check-booking.blade.php ENDPATH**/ ?>