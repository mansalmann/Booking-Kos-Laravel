const swiper = new Swiper('.swiper', {
    slidesPerView: "auto",
    spaceBetween: 20,
    slidesOffsetAfter: 20,
    slidesOffsetBefore: 20,
});